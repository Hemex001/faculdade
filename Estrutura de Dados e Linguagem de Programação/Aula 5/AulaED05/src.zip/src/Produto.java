public class Produto {
    public static void main(String[] args) {
        String nome = "Produto";
        double preco = 39.9;
        int qtdEstoque = 6;
        boolean disponibilidade = true;

        System.out.println("Nome: " + nome);
        System.out.println("Preço: " + preco);
        System.out.println("Quantidade no Estoque: " + qtdEstoque);
        System.out.println("Disponível: " + disponibilidade);
    }
}
